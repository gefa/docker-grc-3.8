from __future__ import print_function
from names import get_full_name


def main():
    print(get_full_name())


if __name__ == "__main__":
    main()
